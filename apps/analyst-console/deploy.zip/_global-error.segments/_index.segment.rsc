1:"$Sreact.fragment"
2:I[71383,["/_next/static/chunks/171118ac6457874f.js","/_next/static/chunks/9a8365549ddeb730.js"],"default"]
3:I[81699,["/_next/static/chunks/171118ac6457874f.js","/_next/static/chunks/9a8365549ddeb730.js"],"default"]
0:{"buildId":"oC2lVNU4Mh6vSB6lCq1t8","rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"loading":null,"isPartial":false}
