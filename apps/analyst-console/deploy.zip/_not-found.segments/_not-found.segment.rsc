1:"$Sreact.fragment"
2:I[71383,["/_next/static/chunks/8203f9cefffc6ec5.js","/_next/static/chunks/736364c955e95685.js","/_next/static/chunks/9a8365549ddeb730.js","/_next/static/chunks/d820a48ecf749539.js","/_next/static/chunks/c013a42be7d44040.js"],"default"]
3:I[81699,["/_next/static/chunks/8203f9cefffc6ec5.js","/_next/static/chunks/736364c955e95685.js","/_next/static/chunks/9a8365549ddeb730.js","/_next/static/chunks/d820a48ecf749539.js","/_next/static/chunks/c013a42be7d44040.js"],"default"]
0:{"buildId":"oC2lVNU4Mh6vSB6lCq1t8","rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"loading":null,"isPartial":false}
