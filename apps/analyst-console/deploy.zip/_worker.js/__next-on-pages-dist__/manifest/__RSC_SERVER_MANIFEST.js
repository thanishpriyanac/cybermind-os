var n={},t=(_,e,o)=>(n.__RSC_SERVER_MANIFEST=_.__RSC_SERVER_MANIFEST=`{
  "node": {},
  "edge": {},
  "encryptionKey": "yUg6F/4A/p4GTsdvfmwvHP8VKnAavKg2/TBLqph4CWo="
}`,n);export{t as __getNamedExports};
