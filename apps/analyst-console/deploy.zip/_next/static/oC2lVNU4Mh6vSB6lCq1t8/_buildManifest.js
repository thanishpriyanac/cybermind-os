self.__BUILD_MANIFEST = {
  "__rewrites": {
    "afterFiles": [
      {
        "source": "/cve/:id",
        "destination": "/view/cve/:id"
      },
      {
        "source": "/firewall/:id",
        "destination": "/view/firewall/:id"
      },
      {
        "source": "/firewall/:id/qbr",
        "destination": "/view/firewall/:id/qbr"
      },
      {
        "source": "/investigations/:id",
        "destination": "/view/investigations/:id"
      },
      {
        "source": "/qbr/:id",
        "destination": "/view/qbr/:id"
      },
      {
        "source": "/vapt/:id",
        "destination": "/view/vapt/:id"
      }
    ],
    "beforeFiles": [],
    "fallback": []
  },
  "sortedPages": [
    "/_app",
    "/_error"
  ]
};self.__BUILD_MANIFEST_CB && self.__BUILD_MANIFEST_CB()