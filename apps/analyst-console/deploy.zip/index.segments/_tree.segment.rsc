:HL["/_next/static/chunks/e836157fb62a430f.css","style"]
0:{"buildId":"oC2lVNU4Mh6vSB6lCq1t8","tree":{"name":"","paramType":null,"paramKey":"","hasRuntimePrefetch":false,"slots":{"children":{"name":"__PAGE__","paramType":null,"paramKey":"__PAGE__","hasRuntimePrefetch":false,"slots":null,"isRootLayout":false}},"isRootLayout":true},"staleTime":300}
